

# import the m5 (gem5) library created when gem5 is built
import m5
from m5.objects import *
from caches import *
#from branch_predictor import *
#from m5.objects.BranchPredictor import *

#import argparse Python parsing module
import argparse

#Adding parameters and options
parser = argparse.ArgumentParser(description='A simple system with 2-level cache.')
parser.add_argument("binary", default="", nargs="?", type=str,
                    help="Path to the binary to execute.")
                    
#Adding size parameter to L1i, L1d and L2 caches
parser.add_argument("--l1i_size",
                    help=f"L1 instruction cache size. Default: 16kB.")
parser.add_argument("--l1d_size",
                    help="L1 data cache size. Default: Default: 64kB.")
parser.add_argument("--l2_size",
                    help="L2 cache size. Default: 256kB.")
                    
#Adding data latency parameter to L1i cache
parser.add_argument("--l1i_data_latency",
                    help="L1i data latency. Default: 2.")
                    
#Adding threadPolicy, fetch1ToFetch2ForwardDelay and decodeInputBufferSize
parser.add_argument("--threadPolicy",
                    help="Thread Scheduling Policy for MinorCPU. Default: 'Random'.")
                    
parser.add_argument("--fetch1ToFetch2ForwardDelay",
                    help="Forward cycle delay from Fetch1 to Fetch2 (1 means next cycle). Default: Default: 1.")
                    
parser.add_argument("--decodeInputBufferSize",
                   help="Size of input buffer to decode cycle-worth of instructions. Default: 1.")

parser.add_argument("-c",
                   help="Benchmark type. Default: './Project1_SPEC-master/429.mcf/src/benchmark'.")
                   
parser.add_argument("-o",
                   help="Benchmark Argument. Default: './Project1_SPEC-master/429.mcf/data/inp.in'.")
                   
parser.add_argument("-I",
                   help="Benchmark instructions. Default: 5000000.")     


options = parser.parse_args()


# Create the system we are going to simulate
system = System()

# Set the clock fequency of the system (and all of its children)
system.clk_domain = SrcClockDomain()
system.clk_domain.clock = '1GHz'
system.clk_domain.voltage_domain = VoltageDomain()

# Set up the system
system.mem_mode = 'timing'               # Use timing accesses
system.mem_ranges = [AddrRange('512MB')] # Create an address range

# Create a simple CPU
system.cpu = O3CPU()


if options.threadPolicy:
    system.cpu.threadPolicy = options.threadPolicy

if options.fetch1ToFetch2ForwardDelay :
    system.cpu.fetch1ToFetch2ForwardDelay  = options.fetch1ToFetch2ForwardDelay 
    
if options.decodeInputBufferSize:
    system.cpu.decodeInputBufferSize = options.decodeInputBufferSize
    

       


#Create L1 cache and pass options
system.cpu.icache = L1ICache(options)
system.cpu.dcache = L1DCache(options)


#Connect caches to CPU port
system.cpu.icache.connectCPU(system.cpu)
system.cpu.dcache.connectCPU(system.cpu)


# Create a memory bus, a system crossbar, in this case
system.membus = SystemXBar()

# Hook the CPU ports up to the membus
#system.cpu.icache_port = system.membus.cpu_side_ports
#system.cpu.dcache_port = system.membus.cpu_side_ports

#system.cpu.icache_port = system.l1_cache.cpu_side

#Create L2 bus
system.l2bus = L2XBar()

#Connect L1 cache to L2 cache
system.cpu.icache.connectBus(system.l2bus)
system.cpu.dcache.connectBus(system.l2bus)

#Create L2 cache and pass options
system.l2cache = L2Cache(options)

#Connect L2 cache to L2 bus and memory bus
system.l2cache.connectCPUSideBus(system.l2bus)
system.l2cache.connectMemSideBus(system.membus)

# create the interrupt controller for the CPU and connect to the membus
system.cpu.createInterruptController()


system.cpu.interrupts[0].pio = system.membus.mem_side_ports
system.cpu.interrupts[0].int_requestor = system.membus.cpu_side_ports
system.cpu.interrupts[0].int_responder = system.membus.mem_side_ports

# Create a DDR3 memory controller and connect it to the membus
system.mem_ctrl = MemCtrl()
system.mem_ctrl.dram = DDR3_1600_8x8()
system.mem_ctrl.dram.range = system.mem_ranges[0]
system.mem_ctrl.port = system.membus.mem_side_ports


#binary = 'configs/tutorial/a.out' #for normal.cpp and find_if.cpp
binary = 'configs/tutorial/binary_search'
#binary = 'configs/tutorial/quick_sort'
#binary = 'configs/tutorial/matmult'
#binary = 'tests/test-progs/hello/bin/x86/linux/hello'

system.workload = SEWorkload.init_compatible(binary)

process = Process()
process.cmd = [binary]
system.cpu.workload = process
system.cpu.createThreads()



# set up the root SimObject and start the simulation
root = Root(full_system = False, system = system)
# instantiate all of the objects we've created above
m5.instantiate()

print("Beginning simulation!")
exit_event = m5.simulate()
print('Exiting @ tick {} because {}'.format(m5.curTick(), exit_event.getCause()))
