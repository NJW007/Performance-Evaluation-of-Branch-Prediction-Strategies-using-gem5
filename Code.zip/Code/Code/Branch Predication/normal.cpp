#include <iostream>
using namespace std;

int func(int arr[], int n, int x)
{
     for (int i = 0; i <= n; i++)
	{
           if ((arr[i] % 2) == 0)
			x--;

		if (x == 0)
		   return arr[i];
	}

	return -1;
}
int main()
{
	int arr[] = { 10, 21, 36, 44, 58 };
	int n = sizeof(arr)/sizeof(arr[0]);
	int x = 1;
	cout << "Normal execution" << (func(arr, n, x));
	return 0;
}



