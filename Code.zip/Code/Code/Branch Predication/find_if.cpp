#include <iostream>    
#include <algorithm>    
#include <vector>       
using namespace std;

bool Even_num (int i) {
  return ((i%2)==0);
}

int main () {


 vector<int> num{ 10, 21, 36, 44, 58 };

  
  vector<int>::iterator it = find_if (num.begin(), num.end(), Even_num);
  cout << "Predicated execution" << *it;
  
  return 0;
}





