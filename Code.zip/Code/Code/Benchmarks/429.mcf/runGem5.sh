# -- an example to run SPEC 429.mcf on gem5, put it under 429.mcf folder --
#export GEM5_DIR=/usr/local/gem5
export GEM5_DIR=gem5/
export BENCHMARK=./src/benchmark
export ARGUMENT=./data/inp.in
build/X86/gem5.opt -d ~/m5out configs/tutorial/proj1.py -c $BENCHMARK -o $ARGUMENT -I 5000000
