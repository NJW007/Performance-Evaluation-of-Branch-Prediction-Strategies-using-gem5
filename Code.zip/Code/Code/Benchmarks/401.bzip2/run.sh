#!/bin/sh

cd data/
../src/benchmark input.program 10
