
# To run benchmarks

export BENCHMARK=./Project1_SPEC-master/429.mcf/src/benchmark
export ARGUMENT=./Project1_SPEC-master/429.mcf/data/inp.in

#export BENCHMARK=./Project1_SPEC-master/401.bzip2/src/benchmark
#export ARGUMENT=./Project1_SPEC-master/401.bzip2/data/input.program

#export BENCHMARK=./Project1_SPEC-master/458.sjeng/src/benchmark
#export ARGUMENT=./Project1_SPEC-master/458.sjeng/data/test.txt



build/X86/gem5.opt -d ~/m5out-429mcf configs/example/se.py -c $BENCHMARK -o $ARGUMENT -I 1000000 --cpu-type=O3CPU --caches --l2cache --l1d_size=64kB --l1i_size=16kB --l2_size=256kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=1 --cacheline_size=64

#build/X86/gem5.opt -d ~/m5out-401bzip2 configs/example/se.py -c $BENCHMARK -o $ARGUMENT -I 1000000 --cpu-type=O3CPU --caches --l2cache --l1d_size=64kB --l1i_size=16kB --l2_size=256kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=1 --cacheline_size=64

#build/X86/gem5.opt -d ~/m5out-458_sjeng configs/example/se.py -c $BENCHMARK -o $ARGUMENT -I 1000000 --cpu-type=O3CPU --caches --l2cache --l1d_size=64kB --l1i_size=16kB --l2_size=256kB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=1 --cacheline_size=64

